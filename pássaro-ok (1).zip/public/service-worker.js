const CACHE_NAME = 'passaro-ok-v2-dynamic';
const OFFLINE_URL = '/offline.html';

// Assets estáticos conhecidos
const PRECACHE_ASSETS = [
  '/',
  '/index.html',
  '/offline.html',
  '/manifest.json'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      console.log('[Service Worker] Precaching static assets');
      return cache.addAll(PRECACHE_ASSETS);
    })
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keyList) => {
      return Promise.all(
        keyList.map((key) => {
          if (key !== CACHE_NAME) {
            console.log('[Service Worker] Removing old cache', key);
            return caches.delete(key);
          }
        })
      );
    })
  );
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  // Ignorar requisições não-GET e chrome-extension
  if (event.request.method !== 'GET' || !event.request.url.startsWith('http')) {
    return;
  }

  const url = new URL(event.request.url);

  // 1. Estratégia para Navegação (HTML): Network First -> Cache -> Offline Fallback
  if (event.request.mode === 'navigate') {
    event.respondWith(
      fetch(event.request)
        .catch(() => {
          return caches.match(event.request)
            .then((cachedResponse) => {
              if (cachedResponse) {
                return cachedResponse;
              }
              // Fallback para SPA (Single Page App) - sempre retorna index.html se estiver em cache
              return caches.match('/index.html')
                .then(index => index || caches.match(OFFLINE_URL));
            });
        })
    );
    return;
  }

  // 2. Estratégia para Assets (JS, CSS, Imagens): Stale-While-Revalidate
  // Isso permite carregar rápido do cache, mas atualiza o cache em segundo plano para a próxima visita.
  // Ideal para arquivos gerados pelo Vite com hash no nome.
  if (
    url.pathname.match(/\.(js|css|png|jpg|jpeg|svg|ico|json)$/)
  ) {
    event.respondWith(
      caches.open(CACHE_NAME).then((cache) => {
        return cache.match(event.request).then((cachedResponse) => {
          const fetchPromise = fetch(event.request).then((networkResponse) => {
            // Se a resposta for válida, atualiza o cache
            if (networkResponse.ok) {
              cache.put(event.request, networkResponse.clone());
            }
            return networkResponse;
          }).catch((err) => {
            console.log('[Service Worker] Fetch failed for asset', err);
            // Se falhar o fetch e não tiver cache, não há muito o que fazer para assets
          });

          return cachedResponse || fetchPromise;
        });
      })
    );
    return;
  }

  // 3. Padrão: Network Only (APIs externas, etc)
  event.respondWith(fetch(event.request));
});